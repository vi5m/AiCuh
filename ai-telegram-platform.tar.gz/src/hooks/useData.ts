import { useState, useEffect, useCallback } from "react";
import {
  userService,
  providerService,
  modelService,
  planService,
  activityService,
  logService,
  statsService,
  settingsService,
  adminService,
} from "@/services/dataService";

// Generic hook for data management
function useService<T>(service: any, method: string = "getAll") {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(() => {
    setLoading(true);
    const result = service[method]();
    setData(result);
    setLoading(false);
  }, [service, method]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { data, loading, refresh, setData };
}

// Users hook
export function useUsers() {
  const { data, loading, refresh } = useService<any>(userService);
  
  const createUser = useCallback((user: any) => {
    userService.create(user);
    refresh();
  }, [refresh]);

  const updateUser = useCallback((id: number, data: any) => {
    userService.update(id, data);
    refresh();
  }, [refresh]);

  const deleteUser = useCallback((id: number) => {
    userService.delete(id);
    refresh();
  }, [refresh]);

  const searchUsers = useCallback((query: string) => {
    return userService.search(query);
  }, []);

  return { users: data, loading, refresh, createUser, updateUser, deleteUser, searchUsers };
}

// Providers hook
export function useProviders() {
  const { data, loading, refresh } = useService<any>(providerService);
  
  const createProvider = useCallback((provider: any) => {
    providerService.create(provider);
    refresh();
  }, [refresh]);

  const updateProvider = useCallback((id: number, data: any) => {
    providerService.update(id, data);
    refresh();
  }, [refresh]);

  const deleteProvider = useCallback((id: number) => {
    providerService.delete(id);
    refresh();
  }, [refresh]);

  return { providers: data, loading, refresh, createProvider, updateProvider, deleteProvider };
}

// Models hook
export function useModels() {
  const { data, loading, refresh } = useService<any>(modelService);
  
  const createModel = useCallback((model: any) => {
    modelService.create(model);
    refresh();
  }, [refresh]);

  const updateModel = useCallback((id: number, data: any) => {
    modelService.update(id, data);
    refresh();
  }, [refresh]);

  const deleteModel = useCallback((id: number) => {
    modelService.delete(id);
    refresh();
  }, [refresh]);

  return { models: data, loading, refresh, createModel, updateModel, deleteModel };
}

// Plans hook
export function usePlans() {
  const { data, loading, refresh } = useService<any>(planService);
  
  const createPlan = useCallback((plan: any) => {
    planService.create(plan);
    refresh();
  }, [refresh]);

  const updatePlan = useCallback((id: number, data: any) => {
    planService.update(id, data);
    refresh();
  }, [refresh]);

  const deletePlan = useCallback((id: number) => {
    planService.delete(id);
    refresh();
  }, [refresh]);

  return { plans: data, loading, refresh, createPlan, updatePlan, deletePlan };
}

// Activities hook
export function useActivities() {
  const { data, loading, refresh } = useService<any>(activityService);
  
  const addActivity = useCallback((activity: any) => {
    activityService.add(activity);
    refresh();
  }, [refresh]);

  return { activities: data, loading, refresh, addActivity };
}

// Logs hook
export function useLogs() {
  const { data, loading, refresh } = useService<any>(logService);
  
  const addLog = useCallback((log: any) => {
    logService.add(log);
    refresh();
  }, [refresh]);

  return { logs: data, loading, refresh, addLog };
}

// Stats hook
export function useStats() {
  const [stats, setStats] = useState<any>({});
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(() => {
    setLoading(true);
    const data = statsService.get();
    setStats(data);
    setLoading(false);
  }, []);

  const updateStats = useCallback((newStats: any) => {
    statsService.update(newStats);
    setStats(newStats);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { stats, loading, refresh, updateStats };
}

// Analytics hook
export function useAnalytics() {
  const [stats, setStats] = useState<any>({});
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(() => {
    setLoading(true);
    const data = statsService.get();
    setStats(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { stats, loading, refresh };
}

// Admins hook
export function useAdmins() {
  const [admins, setAdmins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(() => {
    setLoading(true);
    const data = adminService.getAll();
    setAdmins(data);
    setLoading(false);
  }, []);

  const addAdmin = useCallback((admin: any) => {
    adminService.create(admin);
    refresh();
  }, [refresh]);

  const updateAdmin = useCallback((id: number, data: any) => {
    adminService.update(id, data);
    refresh();
  }, [refresh]);

  const deleteAdmin = useCallback((id: number) => {
    adminService.delete(id);
    refresh();
  }, [refresh]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { admins, loading, refresh, addAdmin, updateAdmin, deleteAdmin };
}

// Settings hook
export function useSettings() {
  const [settings, setSettings] = useState<any>({});
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(() => {
    setLoading(true);
    const data = settingsService.get();
    setSettings(data);
    setLoading(false);
  }, []);

  const updateSettings = useCallback((newSettings: any) => {
    settingsService.update(newSettings);
    setSettings(newSettings);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { settings, loading, refresh, updateSettings };
}