import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Plus,
  Search,
  RefreshCw,
  CheckCircle,
  XCircle,
  AlertCircle,
  Key,
  Globe,
  Clock,
  ArrowUpDown,
  Loader2,
} from "lucide-react";
import { useProviders } from "@/hooks/useData";

export default function ProvidersPage() {
  const { providers, loading, refresh, createProvider, updateProvider, deleteProvider } = useProviders();
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newProvider, setNewProvider] = useState({
    name: "",
    baseUrl: "",
    apiKey: "",
    priority: 1,
    timeout: 30,
    status: "active",
  });

  const filteredProviders = providers.filter(
    (provider: any) =>
      provider.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      provider.baseUrl.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeProviders = providers.filter((p: any) => p.status === "active").length;
  const totalModels = providers.reduce((sum: number, p: any) => sum + (p.modelsCount || 0), 0);
  const totalRequests = providers.reduce((sum: number, p: any) => sum + (p.requestsCount || 0), 0);

  const handleAddProvider = () => {
    createProvider(newProvider);
    setIsAddDialogOpen(false);
    setNewProvider({
      name: "",
      baseUrl: "",
      apiKey: "",
      priority: 1,
      timeout: 30,
      status: "active",
    });
  };

  const handleToggleStatus = (id: number, currentStatus: string) => {
    updateProvider(id, { status: currentStatus === "active" ? "inactive" : "active" });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">AI Providers</h1>
          <p className="text-muted-foreground mt-1">
            Manage your AI service providers and API connections
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={refresh}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Test All
          </Button>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Provider
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Provider</DialogTitle>
                <DialogDescription>
                  Configure a new AI service provider
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Provider Name</label>
                    <Input 
                      placeholder="e.g., OpenAI" 
                      value={newProvider.name}
                      onChange={(e) => setNewProvider({...newProvider, name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Base URL</label>
                    <Input 
                      placeholder="https://api.example.com/v1" 
                      value={newProvider.baseUrl}
                      onChange={(e) => setNewProvider({...newProvider, baseUrl: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">API Key</label>
                  <Input 
                    type="password" 
                    placeholder="Enter API key" 
                    value={newProvider.apiKey}
                    onChange={(e) => setNewProvider({...newProvider, apiKey: e.target.value})}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Priority</label>
                    <Input 
                      type="number" 
                      placeholder="1" 
                      value={newProvider.priority}
                      onChange={(e) => setNewProvider({...newProvider, priority: parseInt(e.target.value) || 1})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Timeout (ms)</label>
                    <Input 
                      type="number" 
                      placeholder="30000" 
                      value={newProvider.timeout}
                      onChange={(e) => setNewProvider({...newProvider, timeout: parseInt(e.target.value) || 30})}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Enable Provider</label>
                  <Switch 
                    checked={newProvider.status === "active"}
                    onCheckedChange={(checked) => setNewProvider({...newProvider, status: checked ? "active" : "inactive"})}
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddProvider}>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Add Provider
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Providers</p>
                <p className="text-2xl font-bold">{providers.length}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Globe className="h-4 w-4 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active</p>
                <p className="text-2xl font-bold text-green-500">{activeProviders}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-green-500/10 flex items-center justify-center">
                <CheckCircle className="h-4 w-4 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Models</p>
                <p className="text-2xl font-bold">{totalModels}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-purple-500/10 flex items-center justify-center">
                <Key className="h-4 w-4 text-purple-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Requests</p>
                <p className="text-2xl font-bold">{totalRequests.toLocaleString()}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-orange-500/10 flex items-center justify-center">
                <ArrowUpDown className="h-4 w-4 text-orange-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Providers Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>All Providers</CardTitle>
          <div className="relative w-72">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search providers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Provider</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Requests</TableHead>
                <TableHead>Models</TableHead>
                <TableHead>Success Rate</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProviders.map((provider: any) => (
                <TableRow key={provider.id}>
                  <TableCell>
                    <div>
                      <p className="text-sm font-medium">{provider.name}</p>
                      <p className="text-xs text-muted-foreground font-mono">
                        {provider.baseUrl}
                      </p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        provider.status === "active"
                          ? "default"
                          : provider.status === "error"
                          ? "destructive"
                          : "secondary"
                      }
                    >
                      {provider.status === "active" ? (
                        <CheckCircle className="mr-1 h-3 w-3" />
                      ) : provider.status === "error" ? (
                        <XCircle className="mr-1 h-3 w-3" />
                      ) : (
                        <AlertCircle className="mr-1 h-3 w-3" />
                      )}
                      {provider.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm font-medium">{provider.priority}</span>
                  </TableCell>
                  <TableCell>{(provider.requestsCount || 0).toLocaleString()}</TableCell>
                  <TableCell>{provider.modelsCount || 0}</TableCell>
                  <TableCell>
                    <span className={`text-sm ${(provider.successRate || 0) >= 95 ? 'text-green-500' : 'text-yellow-500'}`}>
                      {provider.successRate || 0}%
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm" onClick={refresh}>
                        <RefreshCw className="h-3 w-3 mr-1" />
                        Test
                      </Button>
                      <Switch 
                        checked={provider.status === "active"} 
                        onCheckedChange={() => handleToggleStatus(provider.id, provider.status)}
                      />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}