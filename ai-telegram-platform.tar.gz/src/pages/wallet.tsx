import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wallet, Plus, Minus, History, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { useToast } from "@/hooks/use-toast";

export default function WalletPage() {
  const { toast } = useToast();
  const [balance, setBalance] = useState(1250.75);
  const [amount, setAmount] = useState("");
  const [transactions, setTransactions] = useState([
    { id: 1, type: "credit", amount: 500, description: "Deposit", date: "2024-03-20 14:30" },
    { id: 2, type: "debit", amount: 25.5, description: "API Usage", date: "2024-03-20 13:15" },
    { id: 3, type: "credit", amount: 1000, description: "Subscription Payment", date: "2024-03-19 10:00" },
    { id: 4, type: "debit", amount: 15.25, description: "Model Usage", date: "2024-03-19 09:30" },
    { id: 5, type: "credit", amount: 200, description: "Bonus", date: "2024-03-18 16:45" },
  ]);

  const handleAddBalance = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({ title: "Error", description: "Please enter a valid amount", variant: "destructive" });
      return;
    }
    const newTransaction = {
      id: transactions.length + 1,
      type: "credit",
      amount: parseFloat(amount),
      description: "Manual Deposit",
      date: new Date().toISOString().slice(0, 16).replace("T", " "),
    };
    setTransactions([newTransaction, ...transactions]);
    setBalance(balance + parseFloat(amount));
    setAmount("");
    toast({ title: "Success", description: `Added $${amount} to balance` });
  };

  const handleDeductBalance = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({ title: "Error", description: "Please enter a valid amount", variant: "destructive" });
      return;
    }
    if (parseFloat(amount) > balance) {
      toast({ title: "Error", description: "Insufficient balance", variant: "destructive" });
      return;
    }
    const newTransaction = {
      id: transactions.length + 1,
      type: "debit",
      amount: parseFloat(amount),
      description: "Manual Deduction",
      date: new Date().toISOString().slice(0, 16).replace("T", " "),
    };
    setTransactions([newTransaction, ...transactions]);
    setBalance(balance - parseFloat(amount));
    setAmount("");
    toast({ title: "Success", description: `Deducted $${amount} from balance` });
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Wallet</h1>
            <p className="text-muted-foreground">Manage user balances and transactions</p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
              <Wallet className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${balance.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">Available balance</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Credits</CardTitle>
              <ArrowUpRight className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                ${transactions.filter(t => t.type === "credit").reduce((sum, t) => sum + t.amount, 0).toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground">Total deposited</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Debits</CardTitle>
              <ArrowDownRight className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">
                ${transactions.filter(t => t.type === "debit").reduce((sum, t) => sum + t.amount, 0).toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground">Total spent</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Transactions</CardTitle>
              <History className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{transactions.length}</div>
              <p className="text-xs text-muted-foreground">Total transactions</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Manage Balance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount ($)</Label>
                <Input
                  id="amount"
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter amount"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleAddBalance} className="flex-1">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Credit
                </Button>
                <Button onClick={handleDeductBalance} variant="destructive" className="flex-1">
                  <Minus className="mr-2 h-4 w-4" />
                  Deduct
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {transactions.map((transaction) => (
                  <div key={transaction.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-full ${transaction.type === "credit" ? "bg-green-100" : "bg-red-100"}`}>
                        {transaction.type === "credit" ? (
                          <ArrowUpRight className="h-4 w-4 text-green-600" />
                        ) : (
                          <ArrowDownRight className="h-4 w-4 text-red-600" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{transaction.description}</p>
                        <p className="text-sm text-muted-foreground">{transaction.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${transaction.type === "credit" ? "text-green-600" : "text-red-600"}`}>
                        {transaction.type === "credit" ? "+" : "-"}${transaction.amount.toFixed(2)}
                      </p>
                      <Badge variant={transaction.type === "credit" ? "default" : "secondary"}>
                        {transaction.type}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}