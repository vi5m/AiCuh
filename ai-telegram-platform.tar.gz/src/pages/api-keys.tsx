import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Key, 
  Plus, 
  Copy, 
  Trash2, 
  Eye, 
  EyeOff,
  Calendar,
  Activity
} from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { useToast } from "@/hooks/use-toast";

interface APIKey {
  id: string;
  name: string;
  key: string;
  status: "active" | "revoked";
  createdAt: string;
  lastUsed: string;
  usageCount: number;
}

export default function APIKeysPage() {
  const { toast } = useToast();
  const [showKey, setShowKey] = useState<string | null>(null);
  const [newKeyName, setNewKeyName] = useState("");
  const [apiKeys, setApiKeys] = useState<APIKey[]>([
    {
      id: "1",
      name: "Production Key",
      key: "sk_live_51HYsQ2L8K2Q3mN4p5o6r7s8t9u0v1w2x3y4z5",
      status: "active",
      createdAt: "2024-03-01",
      lastUsed: "2024-03-20 14:30",
      usageCount: 1250,
    },
    {
      id: "2",
      name: "Development Key",
      key: "sk_test_9Xy8Z7w6V5u4T3s2R1q0P9o8N7m6L5k4",
      status: "active",
      createdAt: "2024-03-10",
      lastUsed: "2024-03-20 12:15",
      usageCount: 340,
    },
    {
      id: "3",
      name: "Testing Key",
      key: "sk_test_1A2b3C4d5E6f7G8h9I0j1K2l3M4n5",
      status: "revoked",
      createdAt: "2024-02-15",
      lastUsed: "2024-03-15 09:00",
      usageCount: 89,
    },
  ]);

  const generateKey = () => {
    if (!newKeyName.trim()) {
      toast({ title: "Error", description: "Please enter a key name", variant: "destructive" });
      return;
    }
    
    const newKey: APIKey = {
      id: (apiKeys.length + 1).toString(),
      name: newKeyName,
      key: `sk_live_${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`,
      status: "active",
      createdAt: new Date().toISOString().split("T")[0],
      lastUsed: "Never",
      usageCount: 0,
    };
    
    setApiKeys([...apiKeys, newKey]);
    setNewKeyName("");
    toast({ title: "Success", description: "API key generated successfully" });
  };

  const revokeKey = (id: string) => {
    setApiKeys(apiKeys.map(key => 
      key.id === id ? { ...key, status: "revoked" as const } : key
    ));
    toast({ title: "Success", description: "API key revoked" });
  };

  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    toast({ title: "Copied", description: "API key copied to clipboard" });
  };

  const toggleShowKey = (id: string) => {
    setShowKey(showKey === id ? null : id);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">API Keys</h1>
            <p className="text-muted-foreground">Manage API keys for external access</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Generate New Key</CardTitle>
          </CardHeader>
          <CardContent className="flex gap-4">
            <div className="flex-1">
              <Input
                placeholder="Enter key name (e.g., Production, Development)"
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
              />
            </div>
            <Button onClick={generateKey}>
              <Plus className="mr-2 h-4 w-4" />
              Generate Key
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {apiKeys.map((apiKey) => (
            <Card key={apiKey.id}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Key className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{apiKey.name}</h3>
                        <Badge variant={apiKey.status === "active" ? "default" : "secondary"}>
                          {apiKey.status}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          Created: {apiKey.createdAt}
                        </div>
                        <div className="flex items-center gap-1">
                          <Activity className="h-3 w-3" />
                          Usage: {apiKey.usageCount}
                        </div>
                        <div>Last used: {apiKey.lastUsed}</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-2 bg-muted px-3 py-2 rounded-md">
                      <code className="text-sm">
                        {showKey === apiKey.id ? apiKey.key : `${apiKey.key.substring(0, 8)}...`}
                      </code>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleShowKey(apiKey.id)}
                      >
                        {showKey === apiKey.id ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyKey(apiKey.key)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                    {apiKey.status === "active" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => revokeKey(apiKey.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}