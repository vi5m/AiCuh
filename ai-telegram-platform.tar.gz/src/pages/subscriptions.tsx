import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Plus,
  Search,
  CreditCard,
  Users,
  TrendingUp,
  DollarSign,
  CheckCircle,
  Clock,
  AlertCircle,
  Crown,
  Loader2,
} from "lucide-react";
import { usePlans } from "@/hooks/useData";

export default function SubscriptionsPage() {
  const { plans, loading, refresh, createPlan, updatePlan, deletePlan } = usePlans();
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newPlan, setNewPlan] = useState({
    name: "",
    description: "",
    price: 0,
    period: "monthly",
    dailyRequests: 10,
    monthlyRequests: 100,
    maxTokens: 4000,
    features: [] as string[],
    color: "blue",
  });

  const filteredPlans = plans.filter(
    (plan: any) =>
      plan.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      plan.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalUsers = plans.reduce((sum: number, p: any) => sum + (p.usersCount || 0), 0);
  const totalRevenue = plans.reduce((sum: number, p: any) => sum + ((p.revenue || 0)), 0);
  const activePlans = plans.filter((p: any) => p.status !== "inactive").length;

  const handleAddPlan = () => {
    createPlan(newPlan);
    setIsAddDialogOpen(false);
    setNewPlan({
      name: "",
      description: "",
      price: 0,
      period: "monthly",
      dailyRequests: 10,
      monthlyRequests: 100,
      maxTokens: 4000,
      features: [],
      color: "blue",
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Subscriptions</h1>
          <p className="text-muted-foreground mt-1">
            Manage subscription plans and user billing
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Plan
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Plan</DialogTitle>
              <DialogDescription>
                Configure a new subscription plan
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Plan Name</label>
                  <Input 
                    placeholder="e.g., Pro" 
                    value={newPlan.name}
                    onChange={(e) => setNewPlan({...newPlan, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Price ($)</label>
                  <Input 
                    type="number" 
                    step="0.01" 
                    placeholder="29.99" 
                    value={newPlan.price}
                    onChange={(e) => setNewPlan({...newPlan, price: parseFloat(e.target.value) || 0})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Description</label>
                <Input 
                  placeholder="Plan description" 
                  value={newPlan.description}
                  onChange={(e) => setNewPlan({...newPlan, description: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Daily Requests</label>
                  <Input 
                    type="number" 
                    placeholder="500" 
                    value={newPlan.dailyRequests}
                    onChange={(e) => setNewPlan({...newPlan, dailyRequests: parseInt(e.target.value) || 10})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Monthly Requests</label>
                  <Input 
                    type="number" 
                    placeholder="15000" 
                    value={newPlan.monthlyRequests}
                    onChange={(e) => setNewPlan({...newPlan, monthlyRequests: parseInt(e.target.value) || 100})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Max Tokens</label>
                  <Input 
                    type="number" 
                    placeholder="32000" 
                    value={newPlan.maxTokens}
                    onChange={(e) => setNewPlan({...newPlan, maxTokens: parseInt(e.target.value) || 4000})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Period</label>
                  <Input 
                    placeholder="monthly" 
                    value={newPlan.period}
                    onChange={(e) => setNewPlan({...newPlan, period: e.target.value})}
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddPlan}>
                <CheckCircle className="mr-2 h-4 w-4" />
                Create Plan
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Plans</p>
                <p className="text-2xl font-bold">{plans.length}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <CreditCard className="h-4 w-4 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Subscribers</p>
                <p className="text-2xl font-bold text-green-500">{totalUsers.toLocaleString()}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-green-500/10 flex items-center justify-center">
                <Users className="h-4 w-4 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Monthly Revenue</p>
                <p className="text-2xl font-bold">${totalRevenue.toLocaleString()}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-purple-500/10 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-purple-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Plans</p>
                <p className="text-2xl font-bold">{activePlans}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-orange-500/10 flex items-center justify-center">
                <DollarSign className="h-4 w-4 text-orange-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Plans Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {filteredPlans.map((plan: any) => (
          <Card key={plan.id} className={plan.isPopular ? "border-secondary" : ""}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{plan.name}</CardTitle>
                {plan.isPopular && (
                  <Badge className="bg-secondary">
                    <Crown className="mr-1 h-3 w-3" />
                    Popular
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground">{plan.description}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-bold">
                  ${plan.price === 0 ? "Free" : plan.price}
                </span>
                {plan.price > 0 && (
                  <span className="text-muted-foreground">/{plan.period}</span>
                )}
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Daily Requests</span>
                  <span className="font-medium">
                    {plan.dailyRequests === -1 ? "Unlimited" : plan.dailyRequests}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Monthly Requests</span>
                  <span className="font-medium">
                    {plan.monthlyRequests === -1 ? "Unlimited" : plan.monthlyRequests.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Max Tokens</span>
                  <span className="font-medium">{plan.maxTokens.toLocaleString()}</span>
                </div>
              </div>

              <div className="space-y-2">
                {(plan.features || []).map((feature: string) => (
                  <div key={feature} className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Users</span>
                  <span className="font-medium">{(plan.usersCount || 0).toLocaleString()}</span>
                </div>
                <Progress value={totalUsers > 0 ? ((plan.usersCount || 0) / totalUsers) * 100 : 0} className="mt-2" />
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">
                  Edit
                </Button>
                <Button size="sm" className="flex-1">
                  Manage
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}