import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { 
  Plug, 
  Image, 
  Mic, 
  Search, 
  Code, 
  FileText, 
  Wand2,
  Settings,
  Info
} from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { useToast } from "@/hooks/use-toast";

interface Plugin {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  status: "active" | "inactive";
  version: string;
  category: string;
}

export default function PluginsPage() {
  const { toast } = useToast();
  const [plugins, setPlugins] = useState<Plugin[]>([
    {
      id: "image-generation",
      name: "Image Generation",
      description: "Generate images from text descriptions using AI models",
      icon: <Image className="h-5 w-5" />,
      status: "active",
      version: "1.0.0",
      category: "AI",
    },
    {
      id: "speech-to-text",
      name: "Speech to Text",
      description: "Convert voice messages to text using Whisper API",
      icon: <Mic className="h-5 w-5" />,
      status: "active",
      version: "1.0.0",
      category: "AI",
    },
    {
      id: "web-search",
      name: "Web Search",
      description: "Search the web and get relevant results",
      icon: <Search className="h-5 w-5" />,
      status: "inactive",
      version: "1.0.0",
      category: "Utility",
    },
    {
      id: "code-interpreter",
      name: "Code Interpreter",
      description: "Execute and analyze code in multiple languages",
      icon: <Code className="h-5 w-5" />,
      status: "active",
      version: "1.0.0",
      category: "Development",
    },
    {
      id: "file-analysis",
      name: "File Analysis",
      description: "Analyze and summarize uploaded documents",
      icon: <FileText className="h-5 w-5" />,
      status: "inactive",
      version: "1.0.0",
      category: "Utility",
    },
    {
      id: "text-to-speech",
      name: "Text to Speech",
      description: "Convert text responses to voice messages",
      icon: <Mic className="h-5 w-5" />,
      status: "inactive",
      version: "1.0.0",
      category: "AI",
    },
  ]);

  const togglePlugin = (pluginId: string) => {
    setPlugins(plugins.map(plugin => {
      if (plugin.id === pluginId) {
        const newStatus = plugin.status === "active" ? "inactive" : "active";
        toast({
          title: `${plugin.name} ${newStatus === "active" ? "Activated" : "Deactivated"}`,
          description: `Plugin has been ${newStatus === "active" ? "enabled" : "disabled"}.`,
        });
        return { ...plugin, status: newStatus };
      }
      return plugin;
    }));
  };

  const activePlugins = plugins.filter(p => p.status === "active").length;
  const inactivePlugins = plugins.filter(p => p.status === "inactive").length;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Plugins</h1>
            <p className="text-muted-foreground">Manage and configure plugins</p>
          </div>
          <Button>
            <Plug className="mr-2 h-4 w-4" />
            Install Plugin
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Plugins</CardTitle>
              <Plug className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{plugins.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active</CardTitle>
              <Wand2 className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{activePlugins}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inactive</CardTitle>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-muted-foreground">{inactivePlugins}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {plugins.map((plugin) => (
            <Card key={plugin.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {plugin.icon}
                    <CardTitle className="text-lg">{plugin.name}</CardTitle>
                  </div>
                  <Switch
                    checked={plugin.status === "active"}
                    onCheckedChange={() => togglePlugin(plugin.id)}
                  />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{plugin.description}</p>
                
                <div className="flex items-center gap-2">
                  <Badge variant={plugin.status === "active" ? "default" : "secondary"}>
                    {plugin.status}
                  </Badge>
                  <Badge variant="outline">{plugin.category}</Badge>
                </div>

                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Info className="h-3 w-3" />
                    Version {plugin.version}
                  </div>
                  <Button variant="ghost" size="sm">
                    <Settings className="h-3 w-3 mr-1" />
                    Configure
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}