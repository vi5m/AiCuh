import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bot, Save, TestTube, MessageSquare, Settings, Bell, Shield } from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { useToast } from "@/hooks/use-toast";

export default function BotSettingsPage() {
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    botToken: "",
    botUsername: "",
    welcomeMessage: "Welcome! I'm your AI assistant. How can I help you today?",
    helpMessage: "Available commands:\n/start - Start the bot\n/help - Show help\n/models - List available models\n/status - Check your status",
    aboutMessage: "AI Telegram Bot - Powered by advanced AI models",
    maintenanceMode: false,
    enabled: true,
    autoReply: true,
    notifyAdmins: true,
    maxMessageLength: 4000,
    rateLimit: 30,
  });

  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "Bot settings have been updated successfully.",
    });
  };

  const handleTest = () => {
    toast({
      title: "Test Connection",
      description: "Testing bot connection...",
    });
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Bot Settings</h1>
            <p className="text-muted-foreground">Configure your Telegram bot</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleTest}>
              <TestTube className="mr-2 h-4 w-4" />
              Test Connection
            </Button>
            <Button onClick={handleSave}>
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </Button>
          </div>
        </div>

        <Tabs defaultValue="general" className="space-y-4">
          <TabsList>
            <TabsTrigger value="general">
              <Settings className="mr-2 h-4 w-4" />
              General
            </TabsTrigger>
            <TabsTrigger value="messages">
              <MessageSquare className="mr-2 h-4 w-4" />
              Messages
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <Bell className="mr-2 h-4 w-4" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="security">
              <Shield className="mr-2 h-4 w-4" />
              Security
            </TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="h-5 w-5" />
                  Bot Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="botToken">Bot Token</Label>
                    <Input
                      id="botToken"
                      type="password"
                      value={settings.botToken}
                      onChange={(e) => setSettings({ ...settings, botToken: e.target.value })}
                      placeholder="Enter your bot token from @BotFather"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="botUsername">Bot Username</Label>
                    <Input
                      id="botUsername"
                      value={settings.botUsername}
                      onChange={(e) => setSettings({ ...settings, botUsername: e.target.value })}
                      placeholder="@your_bot_username"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="maxMessageLength">Max Message Length</Label>
                    <Input
                      id="maxMessageLength"
                      type="number"
                      value={settings.maxMessageLength}
                      onChange={(e) => setSettings({ ...settings, maxMessageLength: parseInt(e.target.value) })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="rateLimit">Rate Limit (messages/minute)</Label>
                    <Input
                      id="rateLimit"
                      type="number"
                      value={settings.rateLimit}
                      onChange={(e) => setSettings({ ...settings, rateLimit: parseInt(e.target.value) })}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between space-y-0 pt-4">
                  <div className="space-y-0.5">
                    <Label>Bot Status</Label>
                    <p className="text-sm text-muted-foreground">Enable or disable the bot</p>
                  </div>
                  <Switch
                    checked={settings.enabled}
                    onCheckedChange={(checked) => setSettings({ ...settings, enabled: checked })}
                  />
                </div>

                <div className="flex items-center justify-between space-y-0">
                  <div className="space-y-0.5">
                    <Label>Maintenance Mode</Label>
                    <p className="text-sm text-muted-foreground">Put bot in maintenance mode</p>
                  </div>
                  <Switch
                    checked={settings.maintenanceMode}
                    onCheckedChange={(checked) => setSettings({ ...settings, maintenanceMode: checked })}
                  />
                </div>

                <div className="flex items-center justify-between space-y-0">
                  <div className="space-y-0.5">
                    <Label>Auto Reply</Label>
                    <p className="text-sm text-muted-foreground">Automatically reply to messages</p>
                  </div>
                  <Switch
                    checked={settings.autoReply}
                    onCheckedChange={(checked) => setSettings({ ...settings, autoReply: checked })}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messages" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Welcome Message</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={settings.welcomeMessage}
                  onChange={(e) => setSettings({ ...settings, welcomeMessage: e.target.value })}
                  rows={3}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Help Message</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={settings.helpMessage}
                  onChange={(e) => setSettings({ ...settings, helpMessage: e.target.value })}
                  rows={5}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>About Message</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={settings.aboutMessage}
                  onChange={(e) => setSettings({ ...settings, aboutMessage: e.target.value })}
                  rows={2}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between space-y-0">
                  <div className="space-y-0.5">
                    <Label>Notify Admins</Label>
                    <p className="text-sm text-muted-foreground">Send notifications to admins</p>
                  </div>
                  <Switch
                    checked={settings.notifyAdmins}
                    onCheckedChange={(checked) => setSettings({ ...settings, notifyAdmins: checked })}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Security Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Allowed Users</Label>
                  <p className="text-sm text-muted-foreground">Restrict bot to specific users (leave empty for all)</p>
                  <Textarea placeholder="Enter user IDs separated by commas" rows={3} />
                </div>

                <div className="space-y-2">
                  <Label>Blocked Users</Label>
                  <p className="text-sm text-muted-foreground">Block specific users</p>
                  <Textarea placeholder="Enter user IDs separated by commas" rows={3} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}