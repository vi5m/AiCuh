import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useSettings } from "@/hooks/useData";
import { Loader2, Save } from "lucide-react";

export default function SettingsPage() {
  const { settings, loading, updateSettings } = useSettings();
  const [localSettings, setLocalSettings] = useState(settings);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const handleSave = () => {
    updateSettings(localSettings);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground">
            Configure system settings
          </p>
        </div>
        <Button onClick={handleSave}>
          <Save className="mr-2 h-4 w-4" />
          Save Changes
        </Button>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="bot">Bot</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="api">API</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Platform Name</label>
                  <Input
                    value={localSettings?.platformName || ""}
                    onChange={(e) => setLocalSettings({ ...localSettings, platformName: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <Input
                    value={localSettings?.description || ""}
                    onChange={(e) => setLocalSettings({ ...localSettings, description: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Default Language</label>
                  <Input
                    value={localSettings?.defaultLanguage || "en"}
                    onChange={(e) => setLocalSettings({ ...localSettings, defaultLanguage: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Timezone</label>
                  <Input
                    value={localSettings?.timezone || "UTC"}
                    onChange={(e) => setLocalSettings({ ...localSettings, timezone: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bot" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bot Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Bot Token</label>
                  <Input type="password" value="••••••••••••••••" readOnly />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Welcome Message</label>
                  <Input
                    value={localSettings?.welcomeMessage || ""}
                    onChange={(e) => setLocalSettings({ ...localSettings, welcomeMessage: e.target.value })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Maintenance Mode</label>
                  <Switch
                    checked={localSettings?.maintenanceMode || false}
                    onCheckedChange={(checked) => setLocalSettings({ ...localSettings, maintenanceMode: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Enable Bot</label>
                  <Switch
                    checked={localSettings?.enableBot || true}
                    onCheckedChange={(checked) => setLocalSettings({ ...localSettings, enableBot: checked })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Enable Registration</label>
                  <Switch
                    checked={localSettings?.enableRegistration || true}
                    onCheckedChange={(checked) => setLocalSettings({ ...localSettings, enableRegistration: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Require Approval</label>
                  <Switch
                    checked={localSettings?.requireApproval || false}
                    onCheckedChange={(checked) => setLocalSettings({ ...localSettings, requireApproval: checked })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>API Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">API Version</label>
                  <Input value="v1" readOnly />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Rate Limit (requests/minute)</label>
                  <Input
                    type="number"
                    value={localSettings?.rateLimit || 60}
                    onChange={(e) => setLocalSettings({ ...localSettings, rateLimit: parseInt(e.target.value) })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}