import { StatsCard } from "@/components/dashboard/StatsCard";
import { ActivityChart } from "@/components/dashboard/ActivityChart";
import { ModelsChart } from "@/components/dashboard/ModelsChart";
import { StatusCard } from "@/components/dashboard/StatusCard";
import { RecentActivity } from "@/components/dashboard/RecentActivity";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useUsers, useProviders, useModels, useStats, useActivities } from "@/hooks/useData";
import {
  Users,
  Activity,
  MessageSquare,
  Cpu,
  Bot,
  Database,
  TrendingUp,
  Zap,
  Clock,
  ArrowUpRight,
  Download,
  RefreshCw,
} from "lucide-react";

export default function Dashboard() {
  const { users, loading: usersLoading } = useUsers();
  const { providers, loading: providersLoading } = useProviders();
  const { models, loading: modelsLoading } = useModels();
  const { stats, loading: statsLoading } = useStats();
  const { activities, loading: activitiesLoading } = useActivities();

  const activeUsers = users.filter(u => u.status === "active").length;
  const activeProviders = providers.filter(p => p.status === "active").length;
  const activeModels = models.filter(m => m.status === "active").length;

  const statsData = [
    {
      title: "Total Users",
      value: users.length.toLocaleString(),
      description: `${activeUsers} active users`,
      trend: "up" as const,
      trendValue: "+12.5%",
      icon: Users,
      loading: usersLoading,
    },
    {
      title: "Daily Requests",
      value: stats.dailyRequests?.toLocaleString() || "0",
      description: "AI requests today",
      trend: "up" as const,
      trendValue: "+8.2%",
      icon: Activity,
      loading: statsLoading,
    },
    {
      title: "Total Messages",
      value: stats.totalMessages?.toLocaleString() || "0",
      description: "Messages processed",
      trend: "up" as const,
      trendValue: "+15.3%",
      icon: MessageSquare,
      loading: statsLoading,
    },
    {
      title: "Tokens Used",
      value: stats.tokensUsed ? `${(stats.tokensUsed / 1000000).toFixed(1)}M` : "0",
      description: "Tokens consumed",
      trend: "up" as const,
      trendValue: "+22.1%",
      icon: Cpu,
      loading: statsLoading,
    },
  ];

  const statusItems = providers.map(provider => ({
    name: provider.name,
    status: provider.status === "active" ? "online" as const : provider.status === "error" ? "offline" as const : "warning" as const,
    latency: provider.latency || "-",
  }));

  const topModels = models
    .sort((a, b) => (b.requestsCount || 0) - (a.requestsCount || 0))
    .slice(0, 5)
    .map(model => ({
      name: model.name,
      usage: `${((model.requestsCount || 0) / (stats.totalRequests || 1) * 100).toFixed(0)}%`,
      requests: model.requestsCount || 0,
    }));

  const quickStats = [
    {
      icon: Bot,
      iconColor: "text-green-500",
      bgColor: "bg-green-500/10",
      label: "Bot Status",
      value: "Online",
      subtext: "Running normally",
      badge: "default" as const,
      badgeColor: "bg-green-500",
    },
    {
      icon: Database,
      iconColor: "text-blue-500",
      bgColor: "bg-blue-500/10",
      label: "Database",
      value: "Healthy",
      subtext: "12ms response",
      badge: "default" as const,
      badgeColor: "bg-blue-500",
    },
    {
      icon: TrendingUp,
      iconColor: "text-purple-500",
      bgColor: "bg-purple-500/10",
      label: "Success Rate",
      value: `${stats.successRate || 98.5}%`,
      subtext: "Last 24 hours",
      badge: null,
      badgeColor: null,
    },
    {
      icon: Clock,
      iconColor: "text-orange-500",
      bgColor: "bg-orange-500/10",
      label: "Avg Response",
      value: `${stats.avgResponseTime || 245}ms`,
      subtext: "API latency",
      badge: null,
      badgeColor: null,
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Welcome back! Here's what's happening with your platform.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm">
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
          <Button size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statsData.map((stat) => (
          <StatsCard key={stat.title} {...stat} />
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="lg:col-span-4">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg font-semibold">
                Activity Overview
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                User activity and requests over time
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-xs">
                <Zap className="mr-1 h-3 w-3" />
                Live
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <ActivityChart />
          </CardContent>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">
              Top AI Models
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Most used models this week
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topModels.map((model) => (
                <div key={model.name} className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{model.name}</span>
                      <span className="text-sm text-muted-foreground">
                        {model.usage}
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-secondary to-accent transition-all"
                        style={{ width: model.usage }}
                      />
                    </div>
                  </div>
                  <span className="text-xs text-muted-foreground w-16 text-right">
                    {model.requests.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <StatusCard title="System Status" items={statusItems} />
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">
              Quick Stats
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {quickStats.map((item) => (
              <div key={item.label} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`h-8 w-8 rounded-lg ${item.bgColor} flex items-center justify-center`}>
                    <item.icon className={`h-4 w-4 ${item.iconColor}`} />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{item.label}</p>
                    <p className="text-xs text-muted-foreground">{item.subtext}</p>
                  </div>
                </div>
                {item.badge ? (
                  <Badge variant={item.badge} className={item.badgeColor || ""}>{item.value}</Badge>
                ) : (
                  <span className="text-sm font-bold">{item.value}</span>
                )}
              </div>
            ))}
          </CardContent>
        </Card>

        <RecentActivity activities={activities.slice(0, 5)} />
      </div>

      {/* Models Usage Chart */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-lg font-semibold">
              Model Usage Analytics
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Requests and tokens per model
            </p>
          </div>
          <Button variant="outline" size="sm">
            <ArrowUpRight className="mr-2 h-4 w-4" />
            View Details
          </Button>
        </CardHeader>
        <CardContent>
          <ModelsChart />
        </CardContent>
      </Card>
    </div>
  );
}