import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLogs } from "@/hooks/useData";
import { Search, Download, Loader2 } from "lucide-react";

export default function LogsPage() {
  const { logs, loading, refresh } = useLogs();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredLogs = logs.filter((log) =>
    log.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.source.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const systemLogs = filteredLogs.filter((l) => l.type === "system");
  const errorLogs = filteredLogs.filter((l) => l.type === "error");
  const apiLogs = filteredLogs.filter((l) => l.type === "api");

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">System Logs</h1>
          <p className="text-muted-foreground">
            Monitor system activity and errors
          </p>
        </div>
        <Button variant="outline" onClick={refresh}>
          <Download className="mr-2 h-4 w-4" />
          Export
        </Button>
      </div>

      <div className="flex items-center space-x-2">
        <Search className="h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search logs..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="max-w-sm"
        />
      </div>

      <Tabs defaultValue="system" className="space-y-4">
        <TabsList>
          <TabsTrigger value="system">System ({systemLogs.length})</TabsTrigger>
          <TabsTrigger value="errors">Errors ({errorLogs.length})</TabsTrigger>
          <TabsTrigger value="api">API ({apiLogs.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="system" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <div className="divide-y">
                {systemLogs.map((log) => (
                  <div key={log.id} className="p-4 flex items-start gap-3">
                    <Badge variant="outline">{log.level}</Badge>
                    <div className="flex-1">
                      <p className="text-sm">{log.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {log.source} • {new Date(log.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="errors" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <div className="divide-y">
                {errorLogs.map((log) => (
                  <div key={log.id} className="p-4 flex items-start gap-3">
                    <Badge variant="destructive">{log.level}</Badge>
                    <div className="flex-1">
                      <p className="text-sm">{log.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {log.source} • {new Date(log.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="api" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <div className="divide-y">
                {apiLogs.map((log) => (
                  <div key={log.id} className="p-4 flex items-start gap-3">
                    <Badge variant="secondary">{log.level}</Badge>
                    <div className="flex-1">
                      <p className="text-sm">{log.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {log.source} • {new Date(log.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}