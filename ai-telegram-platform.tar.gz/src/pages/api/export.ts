import type { NextApiRequest, NextApiResponse } from "next";
import fs from "fs";
import path from "path";

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "GET") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    const filePath = path.join(process.cwd(), "ai-telegram-platform.tar.gz");
    
    // Check if file exists
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "Export file not found. Please run export first." });
    }

    const stat = fs.statSync(filePath);
    
    res.setHeader("Content-Type", "application/gzip");
    res.setHeader("Content-Length", stat.size);
    res.setHeader("Content-Disposition", "attachment; filename=ai-telegram-platform.tar.gz");
    
    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
  } catch (error) {
    console.error("Export error:", error);
    res.status(500).json({ message: "Failed to export project" });
  }
}