import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Download, 
  FileArchive, 
  CheckCircle, 
  AlertCircle,
  FolderOpen,
  Database,
  Code,
  Settings
} from "lucide-react";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";

export default function ExportPage() {
  const [isExporting, setIsExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState<"idle" | "success" | "error">("idle");

  const handleExport = async () => {
    setIsExporting(true);
    try {
      // In a real implementation, this would trigger a backend endpoint
      // For now, we'll create a client-side download
      const response = await fetch("/api/export");
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "ai-telegram-platform.tar.gz";
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        setExportStatus("success");
      } else {
        setExportStatus("error");
      }
    } catch (error) {
      setExportStatus("error");
    } finally {
      setIsExporting(false);
    }
  };

  const projectStructure = [
    {
      name: "Frontend (Next.js)",
      icon: <Code className="h-5 w-5" />,
      items: [
        "Dashboard with Charts & Statistics",
        "User Management System",
        "AI Providers Management",
        "Models Management",
        "Subscriptions & Plans",
        "System Settings",
        "Logs & Monitoring",
        "Analytics & Reports",
        "Security & RBAC",
      ],
    },
    {
      name: "Backend (FastAPI)",
      icon: <Database className="h-5 w-5" />,
      items: [
        "REST API with JWT Auth",
        "SQLAlchemy Models",
        "Pydantic Schemas",
        "Telegram Bot Integration",
        "AI Router System",
        "Rate Limiting",
        "Audit Logging",
      ],
    },
    {
      name: "Infrastructure",
      icon: <Settings className="h-5 w-5" />,
      items: [
        "Docker & Docker Compose",
        "PostgreSQL Database",
        "Redis Cache",
        "Nginx Reverse Proxy",
        "Alembic Migrations",
        "Pytest Tests",
      ],
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">تصدير المشروع</h1>
          <p className="text-muted-foreground">
            تصدير مشروع منصة الذكاء الاصطناعي المتكاملة
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {projectStructure.map((section) => (
            <Card key={section.name}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {section.name}
                </CardTitle>
                {section.icon}
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  {section.items.map((item) => (
                    <li key={item} className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileArchive className="h-5 w-5" />
              تصدير الملفات
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-4">
                <FolderOpen className="h-8 w-8 text-primary" />
                <div>
                  <p className="font-medium">ai-telegram-platform.tar.gz</p>
                  <p className="text-sm text-muted-foreground">
                    يحتوي على جميع ملفات المشروع
                  </p>
                </div>
              </div>
              <Button
                onClick={handleExport}
                disabled={isExporting}
                className="gap-2"
              >
                <Download className="h-4 w-4" />
                {isExporting ? "جاري التصدير..." : "تنزيل المشروع"}
              </Button>
            </div>

            {exportStatus === "success" && (
              <div className="flex items-center gap-2 p-4 bg-green-50 text-green-700 rounded-lg">
                <CheckCircle className="h-5 w-5" />
                تم تصدير المشروع بنجاح!
              </div>
            )}

            {exportStatus === "error" && (
              <div className="flex items-center gap-2 p-4 bg-red-50 text-red-700 rounded-lg">
                <AlertCircle className="h-5 w-5" />
                حدث خطأ أثناء التصدير. يرجى المحاولة مرة أخرى.
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>تعليمات التثبيت</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-medium">1. تثبيت المتطلبات</h3>
              <pre className="p-4 bg-muted rounded-lg text-sm overflow-x-auto">
                {`# Frontend
npm install

# Backend
cd backend
pip install -r requirements.txt`}
              </pre>
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">2. إعداد قاعدة البيانات</h3>
              <pre className="p-4 bg-muted rounded-lg text-sm overflow-x-auto">
                {`# تشغيل migrations
cd backend
alembic upgrade head`}
              </pre>
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">3. تشغيل المشروع</h3>
              <pre className="p-4 bg-muted rounded-lg text-sm overflow-x-auto">
                {`# Frontend
npm run dev

# Backend
cd backend
uvicorn app.main:app --reload

# أو باستخدام Docker
docker-compose up -d`}
              </pre>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}