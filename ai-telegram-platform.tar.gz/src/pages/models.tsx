import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Plus,
  Search,
  Brain,
  Eye,
  Code,
  MessageSquare,
  Mic,
  Image,
  CheckCircle,
  XCircle,
  Star,
  DollarSign,
  Loader2,
} from "lucide-react";
import { useModels } from "@/hooks/useData";

const capabilityIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  text: MessageSquare,
  vision: Eye,
  coding: Code,
  reasoning: Brain,
  audio: Mic,
  image: Image,
  multimodal: Star,
};

export default function ModelsPage() {
  const { models, loading, refresh, createModel, updateModel, deleteModel } = useModels();
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newModel, setNewModel] = useState({
    name: "",
    modelId: "",
    provider: "",
    providerId: 1,
    capabilities: [] as string[],
    status: "active",
    isFree: false,
    isPremium: false,
    costPer1kTokens: 0,
    maxTokens: 128000,
  });

  const filteredModels = models.filter(
    (model: any) =>
      model.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      model.provider.toLowerCase().includes(searchQuery.toLowerCase()) ||
      model.modelId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeModels = models.filter((m: any) => m.status === "active").length;
  const freeModels = models.filter((m: any) => m.isFree).length;
  const totalRequests = models.reduce((sum: number, m: any) => sum + (m.requestsCount || 0), 0);

  const handleAddModel = () => {
    createModel(newModel);
    setIsAddDialogOpen(false);
    setNewModel({
      name: "",
      modelId: "",
      provider: "",
      providerId: 1,
      capabilities: [],
      status: "active",
      isFree: false,
      isPremium: false,
      costPer1kTokens: 0,
      maxTokens: 128000,
    });
  };

  const handleToggleStatus = (id: number, currentStatus: string) => {
    updateModel(id, { status: currentStatus === "active" ? "inactive" : "active" });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">AI Models</h1>
          <p className="text-muted-foreground mt-1">
            Manage available AI models and their configurations
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Model
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Model</DialogTitle>
              <DialogDescription>
                Configure a new AI model
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Model Name</label>
                  <Input 
                    placeholder="e.g., GPT-4 Turbo" 
                    value={newModel.name}
                    onChange={(e) => setNewModel({...newModel, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Model ID</label>
                  <Input 
                    placeholder="e.g., gpt-4-turbo-preview" 
                    value={newModel.modelId}
                    onChange={(e) => setNewModel({...newModel, modelId: e.target.value})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Provider</label>
                  <Input 
                    placeholder="e.g., OpenAI" 
                    value={newModel.provider}
                    onChange={(e) => setNewModel({...newModel, provider: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Max Tokens</label>
                  <Input 
                    type="number" 
                    placeholder="128000" 
                    value={newModel.maxTokens}
                    onChange={(e) => setNewModel({...newModel, maxTokens: parseInt(e.target.value) || 128000})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Cost per 1K tokens ($)</label>
                <Input 
                  type="number" 
                  step="0.001" 
                  placeholder="0.01" 
                  value={newModel.costPer1kTokens}
                  onChange={(e) => setNewModel({...newModel, costPer1kTokens: parseFloat(e.target.value) || 0})}
                />
              </div>
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Free Model</label>
                <Switch 
                  checked={newModel.isFree}
                  onCheckedChange={(checked) => setNewModel({...newModel, isFree: checked})}
                />
              </div>
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Premium Model</label>
                <Switch 
                  checked={newModel.isPremium}
                  onCheckedChange={(checked) => setNewModel({...newModel, isPremium: checked})}
                />
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddModel}>
                <CheckCircle className="mr-2 h-4 w-4" />
                Add Model
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Models</p>
                <p className="text-2xl font-bold">{models.length}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Brain className="h-4 w-4 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active</p>
                <p className="text-2xl font-bold text-green-500">{activeModels}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-green-500/10 flex items-center justify-center">
                <CheckCircle className="h-4 w-4 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Free Models</p>
                <p className="text-2xl font-bold">{freeModels}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-purple-500/10 flex items-center justify-center">
                <Star className="h-4 w-4 text-purple-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Requests</p>
                <p className="text-2xl font-bold">{totalRequests.toLocaleString()}</p>
              </div>
              <div className="h-8 w-8 rounded-lg bg-orange-500/10 flex items-center justify-center">
                <DollarSign className="h-4 w-4 text-orange-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Models Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>All Models</CardTitle>
          <div className="relative w-72">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search models..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Model</TableHead>
                <TableHead>Provider</TableHead>
                <TableHead>Capabilities</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Cost</TableHead>
                <TableHead>Requests</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredModels.map((model: any) => (
                <TableRow key={model.id}>
                  <TableCell>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium">{model.name}</p>
                        {model.isFree && (
                          <Badge variant="outline" className="text-xs text-green-500">
                            Free
                          </Badge>
                        )}
                        {model.isPremium && (
                          <Badge variant="secondary" className="text-xs">
                            <Star className="mr-1 h-3 w-3" />
                            Premium
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground font-mono">
                        {model.modelId}
                      </p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{model.provider}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {(model.capabilities || []).map((cap: string) => {
                        const Icon = capabilityIcons[cap] || MessageSquare;
                        return (
                          <Badge key={cap} variant="secondary" className="text-xs">
                            <Icon className="mr-1 h-3 w-3" />
                            {cap}
                          </Badge>
                        );
                      })}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={model.status === "active" ? "default" : "secondary"}
                    >
                      {model.status === "active" ? (
                        <CheckCircle className="mr-1 h-3 w-3" />
                      ) : (
                        <XCircle className="mr-1 h-3 w-3" />
                      )}
                      {model.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {model.isFree ? (
                      <span className="text-sm text-green-500 font-medium">Free</span>
                    ) : (
                      <span className="text-sm">${model.costPer1kTokens}/1K</span>
                    )}
                  </TableCell>
                  <TableCell>{(model.requestsCount || 0).toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Switch 
                        checked={model.status === "active"} 
                        onCheckedChange={() => handleToggleStatus(model.id, model.status)}
                      />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}