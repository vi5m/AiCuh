// Data Service for localStorage management
// This simulates a real database with CRUD operations

const STORAGE_KEYS = {
  USERS: "ai_platform_users",
  PROVIDERS: "ai_platform_providers",
  MODELS: "ai_platform_models",
  PLANS: "ai_platform_plans",
  SUBSCRIPTIONS: "ai_platform_subscriptions",
  SETTINGS: "ai_platform_settings",
  LOGS: "ai_platform_logs",
  ACTIVITIES: "ai_platform_activities",
  STATS: "ai_platform_stats",
  ADMINS: "ai_platform_admins",
};

// Generic CRUD operations
function getItems<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

function setItems<T>(key: string, items: T[]): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(items));
}

function generateId(): number {
  return Date.now() + Math.floor(Math.random() * 1000);
}

// Initialize demo data if empty
function initializeData() {
  if (typeof window === "undefined") return;

  // Users
  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    const demoUsers = [
      {
        id: 1,
        telegramId: "123456789",
        username: "johndoe",
        firstName: "John",
        lastName: "Doe",
        email: "john@example.com",
        plan: "Pro",
        status: "active",
        joinDate: "2024-01-15",
        lastActive: "2024-03-20",
        messagesCount: 1250,
        requestsCount: 3400,
        tokensUsed: 450000,
        balance: 25.50,
        language: "en",
      },
      {
        id: 2,
        telegramId: "987654321",
        username: "sarahsmith",
        firstName: "Sarah",
        lastName: "Smith",
        email: "sarah@example.com",
        plan: "Basic",
        status: "active",
        joinDate: "2024-02-01",
        lastActive: "2024-03-19",
        messagesCount: 890,
        requestsCount: 2100,
        tokensUsed: 280000,
        balance: 12.00,
        language: "en",
      },
      {
        id: 3,
        telegramId: "456789123",
        username: "ahmedali",
        firstName: "Ahmed",
        lastName: "Ali",
        email: "ahmed@example.com",
        plan: "Premium",
        status: "active",
        joinDate: "2024-01-20",
        lastActive: "2024-03-20",
        messagesCount: 2100,
        requestsCount: 5600,
        tokensUsed: 780000,
        balance: 150.00,
        language: "ar",
      },
      {
        id: 4,
        telegramId: "789123456",
        username: "mikejohnson",
        firstName: "Mike",
        lastName: "Johnson",
        email: "mike@example.com",
        plan: "Free",
        status: "banned",
        joinDate: "2024-02-10",
        lastActive: "2024-03-15",
        messagesCount: 45,
        requestsCount: 120,
        tokensUsed: 15000,
        balance: 0,
        language: "en",
      },
      {
        id: 5,
        telegramId: "321654987",
        username: "emilybrown",
        firstName: "Emily",
        lastName: "Brown",
        email: "emily@example.com",
        plan: "Pro",
        status: "active",
        joinDate: "2024-03-01",
        lastActive: "2024-03-20",
        messagesCount: 567,
        requestsCount: 1400,
        tokensUsed: 190000,
        balance: 45.00,
        language: "en",
      },
    ];
    setItems(STORAGE_KEYS.USERS, demoUsers);
  }

  // Providers
  if (!localStorage.getItem(STORAGE_KEYS.PROVIDERS)) {
    const demoProviders = [
      {
        id: 1,
        name: "OpenAI",
        baseUrl: "https://api.openai.com/v1",
        apiKey: "sk-••••••••••••••••••••••••",
        type: "openai",
        status: "active",
        priority: 1,
        timeout: 30,
        modelsCount: 5,
        requestsCount: 45000,
        successRate: 98.5,
      },
      {
        id: 2,
        name: "Anthropic",
        baseUrl: "https://api.anthropic.com/v1",
        apiKey: "sk-ant-••••••••••••••••••",
        type: "anthropic",
        status: "active",
        priority: 2,
        timeout: 45,
        modelsCount: 3,
        requestsCount: 28000,
        successRate: 96.2,
      },
      {
        id: 3,
        name: "Google Gemini",
        baseUrl: "https://generativelanguage.googleapis.com/v1",
        apiKey: "AIza••••••••••••••••••",
        type: "gemini",
        status: "active",
        priority: 3,
        timeout: 30,
        modelsCount: 4,
        requestsCount: 15000,
        successRate: 97.8,
      },
      {
        id: 4,
        name: "DeepSeek",
        baseUrl: "https://api.deepseek.com/v1",
        apiKey: "sk-••••••••••••••••••",
        type: "openai",
        status: "active",
        priority: 4,
        timeout: 60,
        modelsCount: 2,
        requestsCount: 8000,
        successRate: 94.5,
      },
      {
        id: 5,
        name: "Groq",
        baseUrl: "https://api.groq.com/openai/v1",
        apiKey: "gsk_••••••••••••••••••",
        type: "openai",
        status: "inactive",
        priority: 5,
        timeout: 15,
        modelsCount: 6,
        requestsCount: 0,
        successRate: 0,
      },
    ];
    setItems(STORAGE_KEYS.PROVIDERS, demoProviders);
  }

  // Models
  if (!localStorage.getItem(STORAGE_KEYS.MODELS)) {
    const demoModels = [
      {
        id: 1,
        name: "GPT-4 Turbo",
        modelId: "gpt-4-turbo-preview",
        provider: "OpenAI",
        providerId: 1,
        status: "active",
        capabilities: ["text", "vision", "coding"],
        costPer1kTokens: 0.01,
        maxTokens: 128000,
        requestsCount: 25000,
        isFree: false,
        isPremium: true,
      },
      {
        id: 2,
        name: "GPT-3.5 Turbo",
        modelId: "gpt-3.5-turbo",
        provider: "OpenAI",
        providerId: 1,
        status: "active",
        capabilities: ["text", "coding"],
        costPer1kTokens: 0.0005,
        maxTokens: 16385,
        requestsCount: 18000,
        isFree: true,
        isPremium: false,
      },
      {
        id: 3,
        name: "Claude 3 Opus",
        modelId: "claude-3-opus-20240229",
        provider: "Anthropic",
        providerId: 2,
        status: "active",
        capabilities: ["text", "vision", "reasoning"],
        costPer1kTokens: 0.015,
        maxTokens: 200000,
        requestsCount: 12000,
        isFree: false,
        isPremium: true,
      },
      {
        id: 4,
        name: "Gemini Pro",
        modelId: "gemini-pro",
        provider: "Google Gemini",
        providerId: 3,
        status: "active",
        capabilities: ["text", "vision", "multimodal"],
        costPer1kTokens: 0.00025,
        maxTokens: 1000000,
        requestsCount: 10000,
        isFree: true,
        isPremium: false,
      },
      {
        id: 5,
        name: "DeepSeek Chat",
        modelId: "deepseek-chat",
        provider: "DeepSeek",
        providerId: 4,
        status: "active",
        capabilities: ["text", "coding", "reasoning"],
        costPer1kTokens: 0.00014,
        maxTokens: 64000,
        requestsCount: 6000,
        isFree: false,
        isPremium: false,
      },
    ];
    setItems(STORAGE_KEYS.MODELS, demoModels);
  }

  // Plans
  if (!localStorage.getItem(STORAGE_KEYS.PLANS)) {
    const demoPlans = [
      {
        id: 1,
        name: "Free",
        description: "Basic access for testing",
        price: 0,
        period: "monthly",
        dailyRequests: 10,
        monthlyRequests: 100,
        maxTokens: 4000,
        models: ["GPT-3.5 Turbo", "Gemini Pro"],
        features: ["Basic AI models", "10 daily requests", "Community support"],
        usersCount: 850,
        revenue: 0,
        color: "gray",
      },
      {
        id: 2,
        name: "Basic",
        description: "For casual users",
        price: 9.99,
        period: "monthly",
        dailyRequests: 50,
        monthlyRequests: 1000,
        maxTokens: 16000,
        models: ["GPT-3.5 Turbo", "Gemini Pro", "DeepSeek Chat"],
        features: ["Standard models", "50 daily requests", "Email support", "Basic analytics"],
        usersCount: 420,
        revenue: 4195.80,
        color: "blue",
      },
      {
        id: 3,
        name: "Pro",
        description: "For power users",
        price: 29.99,
        period: "monthly",
        dailyRequests: 200,
        monthlyRequests: 5000,
        maxTokens: 32000,
        models: ["All Basic models", "GPT-4 Turbo", "Claude 3 Sonnet"],
        features: ["Advanced models", "200 daily requests", "Priority support", "Advanced analytics", "API access"],
        usersCount: 180,
        revenue: 5398.20,
        color: "purple",
      },
      {
        id: 4,
        name: "Premium",
        description: "For businesses",
        price: 99.99,
        period: "monthly",
        dailyRequests: 1000,
        monthlyRequests: 25000,
        maxTokens: 128000,
        models: ["All Pro models", "Claude 3 Opus", "GPT-4 Vision"],
        features: ["All models", "1000 daily requests", "24/7 support", "Custom analytics", "Full API access", "Team collaboration"],
        usersCount: 45,
        revenue: 4499.55,
        color: "amber",
      },
    ];
    setItems(STORAGE_KEYS.PLANS, demoPlans);
  }

  // Activities
  if (!localStorage.getItem(STORAGE_KEYS.ACTIVITIES)) {
    const demoActivities = [
      {
        id: 1,
        user: "John Doe",
        action: "upgraded to",
        target: "Pro Plan",
        time: "2 min ago",
        type: "success",
      },
      {
        id: 2,
        user: "System",
        action: "detected high load on",
        target: "OpenAI Provider",
        time: "5 min ago",
        type: "warning",
      },
      {
        id: 3,
        user: "Sarah Smith",
        action: "registered as",
        target: "new user",
        time: "8 min ago",
        type: "user",
      },
      {
        id: 4,
        user: "System",
        action: "backup completed for",
        target: "database",
        time: "15 min ago",
        type: "system",
      },
      {
        id: 5,
        user: "Mike Johnson",
        action: "failed to connect to",
        target: "Claude API",
        time: "20 min ago",
        type: "error",
      },
    ];
    setItems(STORAGE_KEYS.ACTIVITIES, demoActivities);
  }

  // Logs
  if (!localStorage.getItem(STORAGE_KEYS.LOGS)) {
    const demoLogs = [
      {
        id: 1,
        timestamp: "2024-03-20 14:30:25",
        level: "info",
        source: "Telegram Bot",
        message: "Bot started successfully",
        details: "Webhook configured",
      },
      {
        id: 2,
        timestamp: "2024-03-20 14:31:10",
        level: "warning",
        source: "OpenAI Provider",
        message: "Rate limit approaching",
        details: "85% of quota used",
      },
      {
        id: 3,
        timestamp: "2024-03-20 14:32:45",
        level: "error",
        source: "Claude API",
        message: "Connection timeout",
        details: "Request failed after 45s",
      },
      {
        id: 4,
        timestamp: "2024-03-20 14:35:20",
        level: "info",
        source: "Database",
        message: "Backup completed",
        details: "Size: 2.4GB",
      },
      {
        id: 5,
        timestamp: "2024-03-20 14:40:15",
        level: "success",
        source: "User Auth",
        message: "Admin login successful",
        details: "User: admin@example.com",
      },
    ];
    setItems(STORAGE_KEYS.LOGS, demoLogs);
  }

  // Stats
  if (!localStorage.getItem(STORAGE_KEYS.STATS)) {
    const demoStats = {
      totalUsers: 12450,
      activeUsers: 8934,
      newUsers: 234,
      dailyRequests: 45230,
      totalRequests: 128900,
      totalMessages: 345600,
      tokensUsed: 2400000,
      successRate: 98.5,
      avgResponseTime: 245,
    };
    localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(demoStats));
  }

  // Settings
  if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
    const demoSettings = {
      platformName: "AI Telegram Platform",
      platformDescription: "Advanced AI-powered Telegram Bot Platform",
      defaultLanguage: "en",
      timezone: "UTC",
      maintenanceMode: false,
      registrationEnabled: true,
      maxFileSize: 10,
      rateLimit: 100,
      sessionTimeout: 30,
      webhookUrl: "https://api.example.com/webhook",
      botToken: "••••••••••••••••••••••••",
      welcomeMessage: "Welcome! I'm your AI assistant. How can I help you today?",
      helpMessage: "Available commands:\n/start - Start the bot\n/help - Show this message\n/models - List available models\n/status - Check your account status",
    };
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(demoSettings));
  }

  // Admins
  if (!localStorage.getItem(STORAGE_KEYS.ADMINS)) {
    const demoAdmins = [
      {
        id: 1,
        name: "Super Admin",
        email: "superadmin@example.com",
        role: "super_admin",
        status: "active",
        lastLogin: "2024-03-20 14:00:00",
        permissions: ["all"],
        createdAt: "2024-01-01",
      },
      {
        id: 2,
        name: "Admin User",
        email: "admin@example.com",
        role: "admin",
        status: "active",
        lastLogin: "2024-03-20 12:30:00",
        permissions: ["users", "providers", "models", "settings"],
        createdAt: "2024-01-15",
      },
      {
        id: 3,
        name: "Moderator",
        email: "moderator@example.com",
        role: "moderator",
        status: "active",
        lastLogin: "2024-03-19 16:45:00",
        permissions: ["users", "logs"],
        createdAt: "2024-02-01",
      },
      {
        id: 4,
        name: "Support Agent",
        email: "support@example.com",
        role: "support",
        status: "inactive",
        lastLogin: "2024-03-10 09:20:00",
        permissions: ["users"],
        createdAt: "2024-02-15",
      },
    ];
    setItems(STORAGE_KEYS.ADMINS, demoAdmins);
  }
}

// Users CRUD
export const userService = {
  getAll: () => getItems<any>(STORAGE_KEYS.USERS),
  getById: (id: number) => getItems<any>(STORAGE_KEYS.USERS).find((u) => u.id === id),
  create: (user: any) => {
    const users = getItems<any>(STORAGE_KEYS.USERS);
    const newUser = { ...user, id: generateId() };
    setItems(STORAGE_KEYS.USERS, [...users, newUser]);
    return newUser;
  },
  update: (id: number, data: any) => {
    const users = getItems<any>(STORAGE_KEYS.USERS);
    const updated = users.map((u) => (u.id === id ? { ...u, ...data } : u));
    setItems(STORAGE_KEYS.USERS, updated);
  },
  delete: (id: number) => {
    const users = getItems<any>(STORAGE_KEYS.USERS).filter((u) => u.id !== id);
    setItems(STORAGE_KEYS.USERS, users);
  },
  search: (query: string) => {
    const users = getItems<any>(STORAGE_KEYS.USERS);
    return users.filter(
      (u) =>
        u.username?.toLowerCase().includes(query.toLowerCase()) ||
        u.firstName?.toLowerCase().includes(query.toLowerCase()) ||
        u.lastName?.toLowerCase().includes(query.toLowerCase()) ||
        u.telegramId?.includes(query)
    );
  },
};

// Providers CRUD
export const providerService = {
  getAll: () => getItems<any>(STORAGE_KEYS.PROVIDERS),
  getById: (id: number) => getItems<any>(STORAGE_KEYS.PROVIDERS).find((p) => p.id === id),
  create: (provider: any) => {
    const providers = getItems<any>(STORAGE_KEYS.PROVIDERS);
    const newProvider = { ...provider, id: generateId() };
    setItems(STORAGE_KEYS.PROVIDERS, [...providers, newProvider]);
    return newProvider;
  },
  update: (id: number, data: any) => {
    const providers = getItems<any>(STORAGE_KEYS.PROVIDERS);
    const updated = providers.map((p) => (p.id === id ? { ...p, ...data } : p));
    setItems(STORAGE_KEYS.PROVIDERS, updated);
  },
  delete: (id: number) => {
    const providers = getItems<any>(STORAGE_KEYS.PROVIDERS).filter((p) => p.id !== id);
    setItems(STORAGE_KEYS.PROVIDERS, providers);
  },
};

// Models CRUD
export const modelService = {
  getAll: () => getItems<any>(STORAGE_KEYS.MODELS),
  getById: (id: number) => getItems<any>(STORAGE_KEYS.MODELS).find((m) => m.id === id),
  create: (model: any) => {
    const models = getItems<any>(STORAGE_KEYS.MODELS);
    const newModel = { ...model, id: generateId() };
    setItems(STORAGE_KEYS.MODELS, [...models, newModel]);
    return newModel;
  },
  update: (id: number, data: any) => {
    const models = getItems<any>(STORAGE_KEYS.MODELS);
    const updated = models.map((m) => (m.id === id ? { ...m, ...data } : m));
    setItems(STORAGE_KEYS.MODELS, updated);
  },
  delete: (id: number) => {
    const models = getItems<any>(STORAGE_KEYS.MODELS).filter((m) => m.id !== id);
    setItems(STORAGE_KEYS.MODELS, models);
  },
};

// Plans CRUD
export const planService = {
  getAll: () => getItems<any>(STORAGE_KEYS.PLANS),
  getById: (id: number) => getItems<any>(STORAGE_KEYS.PLANS).find((p) => p.id === id),
  create: (plan: any) => {
    const plans = getItems<any>(STORAGE_KEYS.PLANS);
    const newPlan = { ...plan, id: generateId() };
    setItems(STORAGE_KEYS.PLANS, [...plans, newPlan]);
    return newPlan;
  },
  update: (id: number, data: any) => {
    const plans = getItems<any>(STORAGE_KEYS.PLANS);
    const updated = plans.map((p) => (p.id === id ? { ...p, ...data } : p));
    setItems(STORAGE_KEYS.PLANS, updated);
  },
  delete: (id: number) => {
    const plans = getItems<any>(STORAGE_KEYS.PLANS).filter((p) => p.id !== id);
    setItems(STORAGE_KEYS.PLANS, plans);
  },
};

// Activities
export const activityService = {
  getAll: () => getItems<any>(STORAGE_KEYS.ACTIVITIES),
  add: (activity: any) => {
    const activities = getItems<any>(STORAGE_KEYS.ACTIVITIES);
    const newActivity = { ...activity, id: generateId() };
    setItems(STORAGE_KEYS.ACTIVITIES, [newActivity, ...activities].slice(0, 100));
    return newActivity;
  },
};

// Logs
export const logService = {
  getAll: () => getItems<any>(STORAGE_KEYS.LOGS),
  add: (log: any) => {
    const logs = getItems<any>(STORAGE_KEYS.LOGS);
    const newLog = { ...log, id: generateId() };
    setItems(STORAGE_KEYS.LOGS, [newLog, ...logs].slice(0, 1000));
    return newLog;
  },
};

// Stats
export const statsService = {
  get: () => {
    const data = localStorage.getItem(STORAGE_KEYS.STATS);
    return data ? JSON.parse(data) : {};
  },
  update: (stats: any) => {
    localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(stats));
  },
};

// Settings
export const settingsService = {
  get: () => {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return data ? JSON.parse(data) : {};
  },
  update: (settings: any) => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  },
};

// Admins CRUD
export const adminService = {
  getAll: () => getItems<any>(STORAGE_KEYS.ADMINS),
  getById: (id: number) => getItems<any>(STORAGE_KEYS.ADMINS).find((a) => a.id === id),
  create: (admin: any) => {
    const admins = getItems<any>(STORAGE_KEYS.ADMINS);
    const newAdmin = { ...admin, id: generateId() };
    setItems(STORAGE_KEYS.ADMINS, [...admins, newAdmin]);
    return newAdmin;
  },
  update: (id: number, data: any) => {
    const admins = getItems<any>(STORAGE_KEYS.ADMINS);
    const updated = admins.map((a) => (a.id === id ? { ...a, ...data } : a));
    setItems(STORAGE_KEYS.ADMINS, updated);
  },
  delete: (id: number) => {
    const admins = getItems<any>(STORAGE_KEYS.ADMINS).filter((a) => a.id !== id);
    setItems(STORAGE_KEYS.ADMINS, admins);
  },
};

// Initialize on import
if (typeof window !== "undefined") {
  initializeData();
}

export { STORAGE_KEYS };