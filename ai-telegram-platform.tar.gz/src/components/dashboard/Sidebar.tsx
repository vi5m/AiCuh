"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  LayoutDashboard,
  Users,
  Bot,
  Brain,
  CreditCard,
  Settings,
  Shield,
  BarChart3,
  Plug,
  Key,
  ChevronLeft,
  ChevronRight,
  MessageSquare,
  Wallet,
  Download,
} from "lucide-react";

interface SidebarProps {
  isCollapsed: boolean;
  onToggle: () => void;
}

interface NavItem {
  title: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
}

const navItems: NavItem[] = [
  { title: "Dashboard", href: "/", icon: LayoutDashboard },
  { title: "Users", href: "/users", icon: Users, badge: 1240 },
  { title: "Bot Settings", href: "/bot", icon: Bot },
  { title: "AI Providers", href: "/providers", icon: Brain },
  { title: "Models", href: "/models", icon: MessageSquare },
  { title: "Subscriptions", href: "/subscriptions", icon: CreditCard },
  { title: "Wallet", href: "/wallet", icon: Wallet },
  { title: "Analytics", href: "/analytics", icon: BarChart3 },
  { title: "Plugins", href: "/plugins", icon: Plug },
  { title: "API Keys", href: "/api-keys", icon: Key },
  { title: "Security", href: "/security", icon: Shield },
  { title: "Settings", href: "/settings", icon: Settings },
  { title: "Export Project", href: "/export", icon: Download },
];

export function Sidebar({ isCollapsed, onToggle }: SidebarProps) {
  const pathname = usePathname();

  return (
    <TooltipProvider delayDuration={0}>
      <aside
        className={cn(
          "fixed left-0 top-0 z-40 h-screen border-r bg-card transition-all duration-300",
          isCollapsed ? "w-[70px]" : "w-[260px]"
        )}
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex h-16 items-center justify-between border-b px-4">
            {!isCollapsed && (
              <Link href="/" className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-secondary to-accent">
                  <Bot className="h-5 w-5 text-white" />
                </div>
                <span className="text-lg font-bold text-foreground">
                  AI Platform
                </span>
              </Link>
            )}
            {isCollapsed && (
              <div className="mx-auto flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-secondary to-accent">
                <Bot className="h-5 w-5 text-white" />
              </div>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggle}
              className={cn(
                "h-8 w-8",
                isCollapsed && "absolute -right-4 top-5 rounded-full border bg-background shadow-sm"
              )}
            >
              {isCollapsed ? (
                <ChevronRight className="h-4 w-4" />
              ) : (
                <ChevronLeft className="h-4 w-4" />
              )}
            </Button>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 px-3 py-4">
            <nav className="flex flex-col gap-1">
              {navItems.map((item) => {
                const isActive = pathname === item.href;
                const Icon = item.icon;

                if (isCollapsed) {
                  return (
                    <Tooltip key={item.href} delayDuration={0}>
                      <TooltipTrigger asChild>
                        <Link
                          href={item.href}
                          className={cn(
                            "flex h-10 w-10 items-center justify-center rounded-lg transition-colors",
                            isActive
                              ? "bg-secondary/10 text-secondary"
                              : "text-muted-foreground hover:bg-muted hover:text-foreground"
                          )}
                        >
                          <Icon className="h-5 w-5" />
                          {item.badge && (
                            <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-secondary text-[10px] font-medium text-white">
                              {item.badge > 99 ? "99+" : item.badge}
                            </span>
                          )}
                        </Link>
                      </TooltipTrigger>
                      <TooltipContent side="right" className="flex items-center gap-2">
                        {item.title}
                        {item.badge && (
                          <span className="rounded-full bg-secondary px-2 py-0.5 text-xs text-white">
                            {item.badge}
                          </span>
                        )}
                      </TooltipContent>
                    </Tooltip>
                  );
                }

                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                      isActive
                        ? "bg-secondary/10 text-secondary"
                        : "text-muted-foreground hover:bg-muted hover:text-foreground"
                    )}
                  >
                    <Icon className="h-5 w-5 shrink-0" />
                    <span className="flex-1">{item.title}</span>
                    {item.badge && (
                      <span className="rounded-full bg-secondary px-2 py-0.5 text-xs text-white">
                        {item.badge > 99 ? "99+" : item.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </nav>
          </ScrollArea>

          {/* Bottom Section */}
          <div className="border-t p-3">
            {!isCollapsed ? (
              <div className="rounded-lg bg-muted p-3">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-gradient-to-br from-secondary to-accent" />
                  <div className="flex-1 overflow-hidden">
                    <p className="truncate text-sm font-medium">Admin User</p>
                    <p className="truncate text-xs text-muted-foreground">
                      Super Admin
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <Tooltip delayDuration={0}>
                <TooltipTrigger asChild>
                  <div className="mx-auto h-8 w-8 rounded-full bg-gradient-to-br from-secondary to-accent" />
                </TooltipTrigger>
                <TooltipContent side="right">Admin User</TooltipContent>
              </Tooltip>
            )}
          </div>
        </div>
      </aside>
    </TooltipProvider>
  );
}