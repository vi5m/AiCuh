"use client";

import { useState } from "react";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isCollapsed={isCollapsed} onToggle={() => setIsCollapsed(!isCollapsed)} />
      <Header isCollapsed={isCollapsed} />
      <main
        className="pt-16 transition-all duration-300"
        style={{
          marginLeft: isCollapsed ? "70px" : "260px",
        }}
      >
        <div className="p-6">{children}</div>
      </main>
    </div>
  );
}