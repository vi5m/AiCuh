"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { CheckCircle, XCircle, AlertCircle } from "lucide-react";

interface StatusItem {
  name: string;
  status: "online" | "offline" | "warning";
  latency?: string;
}

interface StatusCardProps {
  title: string;
  items: StatusItem[];
  className?: string;
}

export function StatusCard({ title, items, className }: StatusCardProps) {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {items.map((item) => (
          <div
            key={item.name}
            className="flex items-center justify-between py-2"
          >
            <div className="flex items-center gap-3">
              {item.status === "online" ? (
                <CheckCircle className="h-4 w-4 text-green-500" />
              ) : item.status === "offline" ? (
                <XCircle className="h-4 w-4 text-red-500" />
              ) : (
                <AlertCircle className="h-4 w-4 text-yellow-500" />
              )}
              <span className="text-sm font-medium">{item.name}</span>
            </div>
            <div className="flex items-center gap-2">
              {item.latency && (
                <span className="text-xs text-muted-foreground">
                  {item.latency}
                </span>
              )}
              <span
                className={cn(
                  "h-2 w-2 rounded-full",
                  item.status === "online"
                    ? "bg-green-500"
                    : item.status === "offline"
                    ? "bg-red-500"
                    : "bg-yellow-500"
                )}
              />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}