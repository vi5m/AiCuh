from fastapi import APIRouter
from app.api.v1.endpoints import auth, users, providers, models, subscriptions, stats, settings, logs

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])
api_router.include_router(users.router, prefix="/users", tags=["Users"])
api_router.include_router(providers.router, prefix="/providers", tags=["Providers"])
api_router.include_router(models.router, prefix="/models", tags=["Models"])
api_router.include_router(subscriptions.router, prefix="/subscriptions", tags=["Subscriptions"])
api_router.include_router(stats.router, prefix="/stats", tags=["Statistics"])
api_router.include_router(settings.router, prefix="/settings", tags=["Settings"])
api_router.include_router(logs.router, prefix="/logs", tags=["Logs"])