from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database.base import get_db
from app.models.provider import AIModel
from app.schemas.provider import AIModelUpdate, AIModelResponse
from app.api.v1.endpoints.auth import get_current_admin

router = APIRouter()

@router.get("/", response_model=List[AIModelResponse])
def get_models(db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    return db.query(AIModel).all()

@router.get("/{model_id}", response_model=AIModelResponse)
def get_model(model_id: int, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    model = db.query(AIModel).filter(AIModel.id == model_id).first()
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")
    return model

@router.put("/{model_id}", response_model=AIModelResponse)
def update_model(
    model_id: int,
    model_update: AIModelUpdate,
    db: Session = Depends(get_db),
    current_admin = Depends(get_current_admin)
):
    model = db.query(AIModel).filter(AIModel.id == model_id).first()
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")
    
    for field, value in model_update.dict(exclude_unset=True).items():
        setattr(model, field, value)
    
    db.commit()
    db.refresh(model)
    return model

@router.delete("/{model_id}")
def delete_model(model_id: int, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    model = db.query(AIModel).filter(AIModel.id == model_id).first()
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")
    
    db.delete(model)
    db.commit()
    return {"message": "Model deleted successfully"}