from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.base import get_db
from app.api.v1.endpoints.auth import get_current_admin

router = APIRouter()

# In-memory settings storage (replace with database table in production)
_system_settings = {
    "platform_name": "AI Telegram Platform",
    "platform_description": "Advanced AI-powered Telegram Bot Platform",
    "default_language": "en",
    "timezone": "UTC",
    "registration_enabled": True,
    "maintenance_mode": False,
    "max_file_size": 10,
    "rate_limit": 60,
    "session_timeout": 30,
}

@router.get("/")
def get_settings(current_admin = Depends(get_current_admin)):
    return _system_settings

@router.put("/")
def update_settings(settings: dict, current_admin = Depends(get_current_admin)):
    _system_settings.update(settings)
    return _system_settings