from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database.base import get_db
from app.models.provider import Provider, AIModel
from app.schemas.provider import ProviderCreate, ProviderUpdate, ProviderResponse, AIModelCreate, AIModelUpdate, AIModelResponse
from app.api.v1.endpoints.auth import get_current_admin

router = APIRouter()

@router.get("/", response_model=List[ProviderResponse])
def get_providers(db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    return db.query(Provider).all()

@router.get("/{provider_id}", response_model=ProviderResponse)
def get_provider(provider_id: int, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    provider = db.query(Provider).filter(Provider.id == provider_id).first()
    if not provider:
        raise HTTPException(status_code=404, detail="Provider not found")
    return provider

@router.post("/", response_model=ProviderResponse)
def create_provider(provider: ProviderCreate, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    db_provider = Provider(**provider.dict())
    db.add(db_provider)
    db.commit()
    db.refresh(db_provider)
    return db_provider

@router.put("/{provider_id}", response_model=ProviderResponse)
def update_provider(
    provider_id: int,
    provider_update: ProviderUpdate,
    db: Session = Depends(get_db),
    current_admin = Depends(get_current_admin)
):
    provider = db.query(Provider).filter(Provider.id == provider_id).first()
    if not provider:
        raise HTTPException(status_code=404, detail="Provider not found")
    
    for field, value in provider_update.dict(exclude_unset=True).items():
        setattr(provider, field, value)
    
    db.commit()
    db.refresh(provider)
    return provider

@router.delete("/{provider_id}")
def delete_provider(provider_id: int, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    provider = db.query(Provider).filter(Provider.id == provider_id).first()
    if not provider:
        raise HTTPException(status_code=404, detail="Provider not found")
    
    db.delete(provider)
    db.commit()
    return {"message": "Provider deleted successfully"}

# Models endpoints
@router.get("/{provider_id}/models", response_model=List[AIModelResponse])
def get_provider_models(provider_id: int, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    return db.query(AIModel).filter(AIModel.provider_id == provider_id).all()

@router.post("/{provider_id}/models", response_model=AIModelResponse)
def create_model(provider_id: int, model: AIModelCreate, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    db_model = AIModel(**model.dict(), provider_id=provider_id)
    db.add(db_model)
    db.commit()
    db.refresh(db_model)
    return db_model