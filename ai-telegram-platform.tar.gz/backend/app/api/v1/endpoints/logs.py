from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from app.database.base import get_db
from app.models.log import SystemLog, AuditLog, APIRequestLog
from app.api.v1.endpoints.auth import get_current_admin

router = APIRouter()

@router.get("/system")
def get_system_logs(
    level: Optional[str] = None,
    source: Optional[str] = None,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_admin = Depends(get_current_admin)
):
    query = db.query(SystemLog)
    
    if level:
        query = query.filter(SystemLog.level == level)
    if source:
        query = query.filter(SystemLog.source == source)
    
    return query.order_by(SystemLog.created_at.desc()).limit(limit).all()

@router.get("/audit")
def get_audit_logs(
    admin_id: Optional[int] = None,
    action: Optional[str] = None,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_admin = Depends(get_current_admin)
):
    query = db.query(AuditLog)
    
    if admin_id:
        query = query.filter(AuditLog.admin_id == admin_id)
    if action:
        query = query.filter(AuditLog.action == action)
    
    return query.order_by(AuditLog.created_at.desc()).limit(limit).all()

@router.get("/api")
def get_api_logs(
    method: Optional[str] = None,
    status_code: Optional[int] = None,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_admin = Depends(get_current_admin)
):
    query = db.query(APIRequestLog)
    
    if method:
        query = query.filter(APIRequestLog.method == method)
    if status_code:
        query = query.filter(APIRequestLog.status_code == status_code)
    
    return query.order_by(APIRequestLog.created_at.desc()).limit(limit).all()