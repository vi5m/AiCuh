from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database.base import get_db
from app.models.subscription import Plan, Subscription, Transaction
from app.schemas.subscription import PlanCreate, PlanUpdate, PlanResponse, SubscriptionCreate, SubscriptionResponse, TransactionCreate, TransactionResponse
from app.api.v1.endpoints.auth import get_current_admin

router = APIRouter()

# Plans
@router.get("/plans", response_model=List[PlanResponse])
def get_plans(db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    return db.query(Plan).all()

@router.get("/plans/{plan_id}", response_model=PlanResponse)
def get_plan(plan_id: int, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    plan = db.query(Plan).filter(Plan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    return plan

@router.post("/plans", response_model=PlanResponse)
def create_plan(plan: PlanCreate, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    db_plan = Plan(**plan.dict())
    db.add(db_plan)
    db.commit()
    db.refresh(db_plan)
    return db_plan

@router.put("/plans/{plan_id}", response_model=PlanResponse)
def update_plan(
    plan_id: int,
    plan_update: PlanUpdate,
    db: Session = Depends(get_db),
    current_admin = Depends(get_current_admin)
):
    plan = db.query(Plan).filter(Plan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    
    for field, value in plan_update.dict(exclude_unset=True).items():
        setattr(plan, field, value)
    
    db.commit()
    db.refresh(plan)
    return plan

@router.delete("/plans/{plan_id}")
def delete_plan(plan_id: int, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    plan = db.query(Plan).filter(Plan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    
    db.delete(plan)
    db.commit()
    return {"message": "Plan deleted successfully"}

# Subscriptions
@router.get("/", response_model=List[SubscriptionResponse])
def get_subscriptions(db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    return db.query(Subscription).all()

@router.post("/", response_model=SubscriptionResponse)
def create_subscription(subscription: SubscriptionCreate, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    db_subscription = Subscription(**subscription.dict())
    db.add(db_subscription)
    db.commit()
    db.refresh(db_subscription)
    return db_subscription

# Transactions
@router.get("/transactions", response_model=List[TransactionResponse])
def get_transactions(db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    return db.query(Transaction).all()

@router.post("/transactions", response_model=TransactionResponse)
def create_transaction(transaction: TransactionCreate, db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    db_transaction = Transaction(**transaction.dict())
    db.add(db_transaction)
    db.commit()
    db.refresh(db_transaction)
    return db_transaction