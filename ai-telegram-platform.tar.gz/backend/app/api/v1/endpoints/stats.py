from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database.base import get_db
from app.models.user import User
from app.models.provider import Provider, AIModel
from app.models.subscription import Plan, Subscription, Transaction
from app.models.conversation import Conversation, Message
from app.api.v1.endpoints.auth import get_current_admin

router = APIRouter()

@router.get("/")
def get_stats(db: Session = Depends(get_db), current_admin = Depends(get_current_admin)):
    total_users = db.query(User).count()
    active_users = db.query(User).filter(User.is_active == True).count()
    blocked_users = db.query(User).filter(User.is_blocked == True).count()
    
    total_providers = db.query(Provider).count()
    active_providers = db.query(Provider).filter(Provider.is_active == True).count()
    
    total_models = db.query(AIModel).count()
    active_models = db.query(AIModel).filter(AIModel.is_active == True).count()
    
    total_plans = db.query(Plan).count()
    total_subscriptions = db.query(Subscription).count()
    active_subscriptions = db.query(Subscription).filter(Subscription.is_active == True).count()
    
    total_conversations = db.query(Conversation).count()
    total_messages = db.query(Message).count()
    
    total_revenue = db.query(func.sum(Transaction.amount)).filter(Transaction.type == "credit").scalar() or 0
    
    return {
        "users": {
            "total": total_users,
            "active": active_users,
            "blocked": blocked_users,
        },
        "providers": {
            "total": total_providers,
            "active": active_providers,
        },
        "models": {
            "total": total_models,
            "active": active_models,
        },
        "subscriptions": {
            "total": total_subscriptions,
            "active": active_subscriptions,
            "plans": total_plans,
        },
        "conversations": {
            "total": total_conversations,
            "messages": total_messages,
        },
        "revenue": {
            "total": float(total_revenue),
        }
    }