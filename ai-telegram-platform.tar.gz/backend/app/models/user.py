from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, JSON, ForeignKey
from sqlalchemy.orm import relationship
from app.database.base import Base
from datetime import datetime

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(String, unique=True, index=True)
    username = Column(String, index=True)
    first_name = Column(String)
    last_name = Column(String)
    email = Column(String, unique=True, index=True)
    phone = Column(String)
    
    # Status
    is_active = Column(Boolean, default=True)
    is_blocked = Column(Boolean, default=False)
    is_admin = Column(Boolean, default=False)
    
    # Subscription
    plan_id = Column(Integer, ForeignKey("plans.id"))
    subscription_expires = Column(DateTime)
    
    # Usage
    total_requests = Column(Integer, default=0)
    total_tokens = Column(Integer, default=0)
    daily_requests = Column(Integer, default=0)
    monthly_requests = Column(Integer, default=0)
    
    # Wallet
    balance = Column(Float, default=0.0)
    
    # Metadata
    language = Column(String, default="en")
    timezone = Column(String, default="UTC")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_activity = Column(DateTime)
    
    # Relationships
    plan = relationship("Plan", back_populates="users")
    conversations = relationship("Conversation", back_populates="user")
    transactions = relationship("Transaction", back_populates="user")

class Admin(Base):
    __tablename__ = "admins"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    email = Column(String, unique=True, index=True)
    password_hash = Column(String)
    role = Column(String, default="admin")  # super_admin, admin, moderator, support
    permissions = Column(JSON, default=list)
    is_active = Column(Boolean, default=True)
    last_login = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)