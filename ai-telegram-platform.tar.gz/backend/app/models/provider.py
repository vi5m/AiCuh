from sqlalchemy import Column, Integer, String, Boolean, DateTime, JSON, Float
from app.database.base import Base
from datetime import datetime

class Provider(Base):
    __tablename__ = "providers"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    base_url = Column(String)
    api_key = Column(String)
    api_type = Column(String, default="openai")  # openai, anthropic, google, etc.
    headers = Column(JSON, default=dict)
    timeout = Column(Integer, default=30)
    
    # Status
    is_active = Column(Boolean, default=True)
    is_default = Column(Boolean, default=False)
    priority = Column(Integer, default=1)
    
    # Limits
    rate_limit = Column(Integer, default=60)
    daily_quota = Column(Integer)
    
    # Metadata
    description = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_check = Column(DateTime)
    status = Column(String, default="unknown")  # online, offline, error

class AIModel(Base):
    __tablename__ = "models"
    
    id = Column(Integer, primary_key=True, index=True)
    provider_id = Column(Integer)
    model_id = Column(String, index=True)  # Actual model ID for API
    name = Column(String)
    description = Column(String)
    
    # Capabilities
    supports_text = Column(Boolean, default=True)
    supports_vision = Column(Boolean, default=False)
    supports_coding = Column(Boolean, default=False)
    supports_reasoning = Column(Boolean, default=False)
    supports_audio = Column(Boolean, default=False)
    supports_multimodal = Column(Boolean, default=False)
    
    # Pricing
    input_price = Column(Float, default=0.0)
    output_price = Column(Float, default=0.0)
    
    # Limits
    max_tokens = Column(Integer, default=4096)
    context_window = Column(Integer, default=8192)
    
    # Status
    is_active = Column(Boolean, default=True)
    is_free = Column(Boolean, default=False)
    is_premium = Column(Boolean, default=False)
    display_order = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)