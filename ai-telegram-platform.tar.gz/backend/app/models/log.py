from sqlalchemy import Column, Integer, String, DateTime, JSON, Text
from app.database.base import Base
from datetime import datetime

class SystemLog(Base):
    __tablename__ = "system_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    level = Column(String, default="info")  # debug, info, warning, error, critical
    source = Column(String)  # system, api, telegram, ai
    message = Column(Text)
    details = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    admin_id = Column(Integer)
    admin_name = Column(String)
    action = Column(String)
    target_type = Column(String)  # user, provider, model, setting
    target_id = Column(String)
    details = Column(JSON, default=dict)
    ip_address = Column(String)
    user_agent = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

class APIRequestLog(Base):
    __tablename__ = "api_request_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    method = Column(String)
    path = Column(String)
    status_code = Column(Integer)
    response_time = Column(Float)
    user_id = Column(Integer)
    ip_address = Column(String)
    user_agent = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)