from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

class UserBase(BaseModel):
    telegram_id: Optional[str] = None
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    language: str = "en"
    timezone: str = "UTC"

class UserCreate(UserBase):
    pass

class UserUpdate(BaseModel):
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    is_active: Optional[bool] = None
    is_blocked: Optional[bool] = None
    plan_id: Optional[int] = None
    balance: Optional[float] = None

class UserResponse(UserBase):
    id: int
    is_active: bool
    is_blocked: bool
    is_admin: bool
    plan_id: Optional[int]
    subscription_expires: Optional[datetime]
    total_requests: int
    total_tokens: int
    daily_requests: int
    monthly_requests: int
    balance: float
    created_at: datetime
    updated_at: datetime
    last_activity: Optional[datetime]
    
    class Config:
        from_attributes = True

class AdminBase(BaseModel):
    name: str
    email: EmailStr
    role: str = "admin"
    permissions: List[str] = []
    is_active: bool = True

class AdminCreate(AdminBase):
    password: str

class AdminUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    role: Optional[str] = None
    permissions: Optional[List[str]] = None
    is_active: Optional[bool] = None

class AdminResponse(AdminBase):
    id: int
    last_login: Optional[datetime]
    created_at: datetime
    
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class LoginRequest(BaseModel):
    email: str
    password: str