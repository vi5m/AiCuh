from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime

class ProviderBase(BaseModel):
    name: str
    base_url: str
    api_type: str = "openai"
    headers: Dict[str, Any] = {}
    timeout: int = 30
    rate_limit: int = 60
    daily_quota: Optional[int] = None
    description: Optional[str] = None

class ProviderCreate(ProviderBase):
    api_key: str

class ProviderUpdate(BaseModel):
    name: Optional[str] = None
    base_url: Optional[str] = None
    api_key: Optional[str] = None
    api_type: Optional[str] = None
    headers: Optional[Dict[str, Any]] = None
    timeout: Optional[int] = None
    is_active: Optional[bool] = None
    is_default: Optional[bool] = None
    priority: Optional[int] = None
    rate_limit: Optional[int] = None
    daily_quota: Optional[int] = None
    description: Optional[str] = None

class ProviderResponse(ProviderBase):
    id: int
    is_active: bool
    is_default: bool
    priority: int
    status: str
    created_at: datetime
    updated_at: datetime
    last_check: Optional[datetime]
    
    class Config:
        from_attributes = True

class AIModelBase(BaseModel):
    model_id: str
    name: str
    description: Optional[str] = None
    supports_text: bool = True
    supports_vision: bool = False
    supports_coding: bool = False
    supports_reasoning: bool = False
    supports_audio: bool = False
    supports_multimodal: bool = False
    input_price: float = 0.0
    output_price: float = 0.0
    max_tokens: int = 4096
    context_window: int = 8192

class AIModelCreate(AIModelBase):
    provider_id: int

class AIModelUpdate(BaseModel):
    model_id: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    supports_text: Optional[bool] = None
    supports_vision: Optional[bool] = None
    supports_coding: Optional[bool] = None
    supports_reasoning: Optional[bool] = None
    supports_audio: Optional[bool] = None
    supports_multimodal: Optional[bool] = None
    input_price: Optional[float] = None
    output_price: Optional[float] = None
    max_tokens: Optional[int] = None
    context_window: Optional[int] = None
    is_active: Optional[bool] = None
    is_free: Optional[bool] = None
    is_premium: Optional[bool] = None
    display_order: Optional[int] = None

class AIModelResponse(AIModelBase):
    id: int
    provider_id: int
    is_active: bool
    is_free: bool
    is_premium: bool
    display_order: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True