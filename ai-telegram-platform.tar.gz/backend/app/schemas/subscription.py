from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime

class PlanBase(BaseModel):
    name: str
    description: Optional[str] = None
    daily_requests: int = 100
    monthly_requests: int = 3000
    max_tokens: int = 4096
    max_messages: int = 1000
    models: List[str] = []
    features: List[str] = []
    price_monthly: float = 0.0
    price_yearly: float = 0.0
    currency: str = "USD"

class PlanCreate(PlanBase):
    pass

class PlanUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    daily_requests: Optional[int] = None
    monthly_requests: Optional[int] = None
    max_tokens: Optional[int] = None
    max_messages: Optional[int] = None
    models: Optional[List[str]] = None
    features: Optional[List[str]] = None
    price_monthly: Optional[float] = None
    price_yearly: Optional[float] = None
    currency: Optional[str] = None
    is_active: Optional[bool] = None
    is_default: Optional[bool] = None
    display_order: Optional[int] = None

class PlanResponse(PlanBase):
    id: int
    is_active: bool
    is_default: bool
    display_order: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class SubscriptionBase(BaseModel):
    user_id: int
    plan_id: int
    starts_at: datetime
    expires_at: Optional[datetime] = None

class SubscriptionCreate(SubscriptionBase):
    pass

class SubscriptionResponse(SubscriptionBase):
    id: int
    is_active: bool
    is_cancelled: bool
    cancelled_at: Optional[datetime]
    payment_method: Optional[str]
    payment_id: Optional[str]
    amount: Optional[float]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class TransactionBase(BaseModel):
    user_id: int
    type: str  # credit, debit, refund
    amount: float
    currency: str = "USD"
    description: Optional[str] = None
    payment_method: Optional[str] = None
    payment_id: Optional[str] = None

class TransactionCreate(TransactionBase):
    pass

class TransactionResponse(TransactionBase):
    id: int
    status: str
    metadata: Dict[str, Any]
    created_at: datetime
    
    class Config:
        from_attributes = True